from django.shortcuts import render, redirect
from .form import ImageForm
from .models import *

def insert_page2(request):
    return render(request, "practice_app2/index3.html")



def insert_data2(request):
    d_name_char = request.POST['char_name']
    d_iteger = request.POST['integer']
    d_slug = request.POST['slug']
    d_text = request.POST['text']
    d_url = request.POST['url']
    d_choice = request.POST['choice']
    

    
    
    # if d_bool == "on":
    #     d_bool_val = True
    # else:
    #     d_bool_val = False

    # new_user = model_practice_app.objects.create(char_name_field=d_char, date_field=d_date, decimal_field=d_decimal, email_field=d_email, boolean_only=d_bool)
    new_user = model_practice2.objects.create(char_name_field2=d_name_char, integer_field=d_iteger, slug_field=d_slug, text_field=d_text, url_field=d_url, choice_field=d_choice)
    print(new_user)
    # return redirect('show_practice_page')

def index4(request):
    if request.method == "POST":
        form=ImageForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            obj=form.instance
            return render(request,"practice_app2/index4.html",{"obj":obj})
    else:
        form=ImageForm()
    img=model_practice4.objects.all()
    print(img)
    return render(request,"practice_app2/index4.html",{"img":img,"form":form})


def index4_1(request):
    return render(request, "practice_app2/index4_1.html")

def insert4_1(request):
    d_char_name = request.POST['char_name']
    # d_image = request.POST['image']
    f_image = request.FILES['image']
    f_file = request.FILES['file']
    # path = 'images/'+ d_image
    # print(d_image)
    print(f_image)
    print(f_file)
    # print(path)
    new_image = model_practice4.objects.create(name_char_field3=d_char_name, image_field=f_image, file_field=f_file)
    new_image.save()
    print(new_image.image_field)
    print(new_image.image_field.url)
    all_data = model_practice4.objects.all()
    print(all_data)
    return render(request, "practice_app2/show4_1.html", {"key1": all_data})
    # return redirect('show_4_1')

def show4_1(request):
    all_data = model_practice4.objects.all()
    print(all_data)
    return render(request, "practice_app2/show4_1.html", {"key1": all_data})


def data(request, id):
    data = model_practice4.objects.get(id=id)
    print(data.file_field)
    print(data.file_field.url)


# def index_s(request):

def show_fkey(request, email):

    s_data = model_student.objects.get(s_email=email)
    print(s_data)
    sd_data = model_sd.objects.get(sd_email=email)
    print(sd_data)
    return render(request, "practice_app2/show_fkey.html", {"key1":s_data, "key2":sd_data})

def show_fkey_all(request):
    s_data_all = model_student.objects.all()
    s_data_all_list = list(s_data_all)
    print(s_data_all_list[1].s_email)
    sd_data_all = model_sd.objects.all()
    sd_data_all_list = list(sd_data_all)
    # print(s_data_all)
    # print(sd_data_all_list)
    # all_data = []

    # for i in s_data_all_list:
    #     # print(i['s_email'])
    #     for j in sd_data_all_list:
    #         # print(j['sd_email_id'])
    #         if i["s_email"] == j["sd_email_id"]:
    #             print(i["s_last_name"])
    #             print(j["sd_email_id"])
    #             object = {"s_first_name":i["s_first_name"], "s_first_name":i["s_last_name"], "s_email":i["s_email"], "s_emp_password":i["s_emp_password"], "sd_branch":j["sd_branch"], "sd_age":j["sd_age"], "sd_contact":j["sd_contact"], "sd_city":j["sd_city"]}
    #             all_data.append(object)
                
                
    # print(all_data)
    
    # all_data = []
    # for i in s_data_all_list:
    #     # print(i.s_email)
    #     # object = {}
    #     for j in sd_data_all_list:
    #         # print(j.sd_email_id)
    #         if i.s_email == j.sd_email_id: 
    #             # print(i.s_last_name)
    #             # print(j.sd_email_id)
    #             print(i.s_email)
    #             object = {"id":i.id, "s_first_name":i.s_first_name, "s_last_name":i.s_last_name, "s_email":i.s_email, "s_emp_password":i.s_emp_password, "sd_branch":j.sd_branch, "sd_age":j.sd_age, "sd_contact":j.sd_contact, "sd_city":j.sd_city} 
    #             all_data.append(object)
    
    # print(all_data)
    # return render(request,"practice_app2/show_fkey_all.html", {"key1":all_data})

    all_data_list = []
    for i in s_data_all:
        data = model_sd.objects.filter(sd_email_id = i.s_email).first()
        print(data.sd_email)
        object = {"id":i.id, "s_first_name":i.s_first_name, "s_last_name":i.s_last_name, "s_email":i.s_email, "s_emp_password":i.s_emp_password, "sd_branch":data.sd_branch, "sd_age":data.sd_age, "sd_contact":data.sd_contact, "sd_city":data.sd_city}
        all_data_list.append(object)


    
    # print(all_data_list[0].sd_email_id)
    print(all_data_list)
    return render(request,"practice_app2/show_fkey_all.html", {"key1":all_data_list})
 






def index_s_fkey_page(request):
    return render(request, "practice_app2/index_s_fkey.html")
def index_s_fkey(request):
    s_fname = request.POST["first_name"]
    s_lname = request.POST["last_name"]
    s_email = request.POST["email"]
    s_pass = request.POST["password"]
    new_student = model_student.objects.create(s_first_name=s_fname, s_last_name=s_lname, s_email=s_email, s_emp_password = s_pass)
    print(new_student)
    return redirect('index_sd_fkey_page', s_email)
    # return redirect('index_sd_fkey', s_email)
    # return render(request, "practice_app2/index_sd_fkey.html")


def index_sd_fkey_page(request, email): 
    return render(request, "practice_app2/index_sd_fkey.html", {"key1":email})
    
def index_sd_fkey(request):
    # print(email)
    # return render(request, "practice_app2/index_sd_fkey.html")
    # if(sd_email==email):
    #     get_sd_data = model_sd.objects.get(sd_email=email)
    #     print(get_sd_data.sd_first_name)
    
    # print(email)
    # s_data = model_student.objects.filter(s_email='kailee@gmail.com').first()
    # new_sd = model_sd.objects.create(sd_first_name='ms', sd_branch="tech", sd_age=30, sd_contact="+12123456987", sd_email=s_data, sd_city="goa")
    # print(s_data.s_email)
    sd_fname = request.POST["first_name"]
    sd_branch = request.POST["branch"]
    sd_email_get = request.POST["email"]
    s_data = model_student.objects.get(s_email=sd_email_get)
    
    # sd_email = model_student.objects.filter(s_email='ms.marvel@marvel.com')
    # print("this is email", sd_email[0].s_email)
    sd_age = request.POST["age"]
    sd_contact = request.POST["contact"]
    sd_city = request.POST["city"]

    new_sd = model_sd.objects.create(sd_first_name=sd_fname, sd_branch=sd_branch, sd_age=sd_age, sd_contact=sd_contact, sd_email=s_data, sd_city=sd_city)
    # print(sd_email)
    # new_sd.save()
    return redirect('show_fkey',sd_email_get)

# one_to_many relationship

def index_sc_page(request):
    # (request, email)
    all_data = model_student.objects.all()
    all_email = []
    for i in all_data:
        data = model_sd.objects.filter(sd_email_id=i.s_email).first()
        print(data.sd_email)
        all_email.append(data.sd_email_id)

    print(all_email)
    return render(request,"practice_app2/index_sc.html", {"key1":all_email})


def index_sc(request):
     sc_branch = request.POST["branch"]
     sc_email = request.POST["email"]
     sc_data = model_student.objects.get(s_email=sc_email)

     new_sc = model_sc.objects.create(sc_branch=sc_branch, sc_email=sc_data)
     return redirect('show_fkey', sc_email)

def show_sc(request):
    s_data_all = model_student.objects.all()
    # s_data_all_list = list(s_data_all)
    # print(s_data_all_list[1].s_email)
    # sc_data_all = model_sc.objects.all()
    # sd_data_all_list = list(sd_data_all)


    all_data_list = []
    for i in s_data_all:
        print(i.s_email)
        data = model_sc.objects.filter(sc_email_id = i.s_email)
        print(data)
        for j in data:
            if(j.sc_email_id == i.s_email):
                print(j)
                object = {"id":i.id, "s_first_name":i.s_first_name, "s_last_name":i.s_last_name, "s_email":i.s_email, "s_emp_password":i.s_emp_password, "sd_branch":j.sc_branch, "sc_id":j.id}
                all_data_list.append(object)

                
            
            # print(j.sc_email_id)
    print(all_data_list)
    #     print(data.sd_email)
    #     object = {"id":i.id, "s_first_name":i.s_first_name, "s_last_name":i.s_last_name, "s_email":i.s_email, "s_emp_password":i.s_emp_password, "sd_branch":data.sd_branch, "sd_age":data.sd_age, "sd_contact":data.sd_contact, "sd_city":data.sd_city}
    #     all_data_list.append(object)
    # all_data_list = []     


    # all_data_list = []
    # for i in s_data_all:
    #     data = model_sc.objects.filter(sc_email_id = i.s_email)
    #     all_data_list.append(data)
    #     print(data)


    # print(all_data_list[3][1])
    # all_objects = []
    # for i in all_data_list:
    #     if len(i) != 0:
    #         for c in i:
    #             data_filter = model_student.objects.filter(s_email=email).first()
                
    #             object = {"id":data_filter.id, "s_first_name":data_filter.s_first_name, "s_last_name":data_filter.s_last_name, "s_email":data_filter.s_email, "s_emp_password":data_filter.s_emp_password, "sd_branch":c}
    #             all_objects.append(object)

    #         print(c)

    # print(all_objects)
 
    # # print(all_data_list[0].sd_email_id)
    # # print(all_data_list)
    return render(request,"practice_app2/show_fkey_all.html", {"key1":all_data_list})

# many to many

def index_movies_page(request):
    return render(request, "practice_app2/index_movies.html")

def index_movies(request):
    m_name = request.POST["name"]
    new_movie = model_movies.objects.create(m_name=m_name)
    print(new_movie)

def index_characters_page(request):
    all_data = model_movies.objects.all()
    all_movies = []
    for i in all_data:
        print(i.m_name)

        # data = model_characters.objects.filter(id = i.id).first()
        # print(data.c_name)
        all_movies.append(i.m_name)

    print(all_movies)
    return render(request, "practice_app2/index_characters.html", {"key1":all_movies})

def index_characters(request):
    c_name = request.POST["c_name"]
    movie_name = request.POST["movie"]
    # movie_name = model_movies.objects.filter(id=id).first()
    new_character = model_characters.objects.create(c_name=c_name)
    new_movie_character = model_characters_c_movie.objects.create(model_characters_id =id, model_movies_id=id)
    print(new_character)

def index_movies_characters_page(request):
    return render(request,"practice_app2/index_moves_characers.html")

def index_movies_characters(request,id):
    c_name = model_movies.objects.filter(id=id).first()
    m_name = model_characters.objects.filter(id=id).first()
    print(c_name)
    print(m_name)