from django.shortcuts import render, redirect
from .form import ImageForm
from .models import *

def insert_page2(request):
    return render(request, "practice_app2/index3.html")



def insert_data2(request):
    d_name_char = request.POST['char_name']
    d_iteger = request.POST['integer']
    d_slug = request.POST['slug']
    d_text = request.POST['text']
    d_url = request.POST['url']
    d_choice = request.POST['choice']
    

    
    
    # if d_bool == "on":
    #     d_bool_val = True
    # else:
    #     d_bool_val = False

    # new_user = model_practice_app.objects.create(char_name_field=d_char, date_field=d_date, decimal_field=d_decimal, email_field=d_email, boolean_only=d_bool)
    new_user = model_practice2.objects.create(char_name_field2=d_name_char, integer_field=d_iteger, slug_field=d_slug, text_field=d_text, url_field=d_url, choice_field=d_choice)
    print(new_user)
    # return redirect('show_practice_page')

def index4(request):
    if request.method == "POST":
        form=ImageForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            obj=form.instance
            return render(request,"practice_app2/index4.html",{"obj":obj})
    else:
        form=ImageForm()
    img=model_practice4.objects.all()
    return render(request,"practice_app2/index4.html",{"img":img,"form":form})
