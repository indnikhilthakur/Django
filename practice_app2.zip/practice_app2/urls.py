from django.urls import include, path

from . import views



urlpatterns = [
    path("insert_page2/", views.insert_page2, name="insert_page2"),
    path("insert_data2/", views.insert_data2, name="insert_data2"),
  
    path("index4/", views.index4, name="index4"),
    # path("insert_practice_data/", views.insert_practice_data, name="insert_practice_data"),
    # path("show_practice_page/", views.show_practice_page, name="show_practice_page")
    
]