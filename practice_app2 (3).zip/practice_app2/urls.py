from django.urls import include, path

from . import views



urlpatterns = [
    path("insert_page2/", views.insert_page2, name="insert_page2"),
    path("insert_data2/", views.insert_data2, name="insert_data2"),
  
    path("index4/", views.index4, name="index4"),
    path("index4_1/", views.index4_1, name="index4_1"),
    path("insert4_1/", views.insert4_1, name="insert4_1"),
    path("show4_1/", views.show4_1, name="show4_1"),
    path("data/<int:id>", views.data, name="data"),
    path("show_fkey/<str:email>", views.show_fkey, name="show_fkey"),
    path("index_s_fkey_page/", views.index_s_fkey_page, name="index_s_fkey_page"),
    path("index_s_fkey/", views.index_s_fkey, name="index_s_fkey"),
    path("index_sd_fkey/", views.index_sd_fkey, name="index_sd_fkey"),
    path("index_sd_fkey_page/<str:email>", views.index_sd_fkey_page, name="index_sd_fkey_page"),
    path("show_fkey_all/", views.show_fkey_all, name="show_fkey_all")
    # path("index_sd_fkey1", views.index_sd_fkey1, name="index_sd_fkey1"),
    # path("insert_practice_data/", views.insert_practice_data, name="insert_practice_data"),
    # path("show_practice_page/", views.show_practice_page, name="show_practice_page")
    
]