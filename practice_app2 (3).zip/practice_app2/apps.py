from django.apps import AppConfig


class PracticeApp2Config(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "practice_app2"
