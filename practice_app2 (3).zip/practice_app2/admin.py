from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(model_practice2)
admin.site.register(model_practice4)
admin.site.register(model_student)
admin.site.register(model_sd)
