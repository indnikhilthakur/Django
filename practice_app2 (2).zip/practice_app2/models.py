from django.db import models
# from django.utils import timezone
from django.template.defaultfilters import slugify

city_choices = (
    ("one", "pune"),
    ("two", "mumbai"),
    ("three", "goa"),
    ("four", "vengurla")
)


class model_practice2(models.Model):
    char_name_field2 = models.CharField(max_length= 100)
    integer_field = models.IntegerField()
    slug_field = models.SlugField(default=True)
    text_field = models.TextField()
    url_field = models.URLField(max_length=100)
    choice_field = models.CharField(max_length=10, choices=city_choices)

    

    def __str__(self) -> str:
        return self.char_name_field2

def save(self):
    self.slug_field = slugify(self.text_field[:30])



class model_practice4(models.Model):
    name_char_field3 = models.CharField(max_length=100)
    image_field = models.ImageField(null=True, blank=True, upload_to='images/')

    def __str__(self) -> str:
        return self.name_char_field3

        