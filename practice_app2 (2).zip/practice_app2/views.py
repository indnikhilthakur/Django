from django.shortcuts import render, redirect
from .form import ImageForm
from .models import *

def insert_page2(request):
    return render(request, "practice_app2/index3.html")



def insert_data2(request):
    d_name_char = request.POST['char_name']
    d_iteger = request.POST['integer']
    d_slug = request.POST['slug']
    d_text = request.POST['text']
    d_url = request.POST['url']
    d_choice = request.POST['choice']
    

    
    
    # if d_bool == "on":
    #     d_bool_val = True
    # else:
    #     d_bool_val = False

    # new_user = model_practice_app.objects.create(char_name_field=d_char, date_field=d_date, decimal_field=d_decimal, email_field=d_email, boolean_only=d_bool)
    new_user = model_practice2.objects.create(char_name_field2=d_name_char, integer_field=d_iteger, slug_field=d_slug, text_field=d_text, url_field=d_url, choice_field=d_choice)
    print(new_user)
    # return redirect('show_practice_page')

def index4(request):
    if request.method == "POST":
        form=ImageForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            obj=form.instance
            return render(request,"practice_app2/index4.html",{"obj":obj})
    else:
        form=ImageForm()
    img=model_practice4.objects.all()
    print(img)
    return render(request,"practice_app2/index4.html",{"img":img,"form":form})


def index4_1(request):
    return render(request, "practice_app2/index4_1.html")

def insert4_1(request):
    d_char_name = request.POST['char_name']
    # d_image = request.POST['image']
    f_image = request.FILES['image']
    # path = 'images/'+ d_image
    # print(d_image)
    print(f_image)
    # print(path)
    new_image = model_practice4.objects.create(name_char_field3=d_char_name, image_field=f_image)
    new_image.save()
    print(new_image.image_field)
    print(new_image.image_field.url)
    all_data = model_practice4.objects.all()
    print(all_data)
    return render(request, "practice_app2/show4_1.html", {"key1": all_data})
    # return redirect('show_4_1')

def show4_1(request):
    all_data = model_practice4.objects.all()
    print(all_data)
    return render(request, "practice_app2/show4_1.html", {"key1": all_data})


def data(request, id):
    data = model_practice4.objects.get(id=id)
    print(data.image_field)
    print(data.image_field.url)
